RustDesk 1.5.1 corresponding source archive

1. Extract rustdesk-1.5.1-source.tar.gz.
2. Extract hbb_common-fae47e0-source.tar.gz, then place its contents under rustdesk-1.5.1/libs/hbb_common.
3. Follow the upstream Windows/Flutter build instructions, .github/workflows, build.py, Cargo.toml/Cargo.lock and Flutter dependency manifests in that release source. Obtain the build toolchains and dependencies identified there. The RustDesk client included by GameScreen is an unmodified upstream binary; GameScreen has no RustDesk patches.

Upstream release source commit: 23e5bb471a040d62f0a6ad52591fb30784265b73
Upstream hbb_common submodule commit: fae47e024dd83cef6aaecde0aa7d11731df11649
https://github.com/rustdesk/rustdesk/tree/1.5.1
https://github.com/rustdesk/hbb_common/tree/fae47e024dd83cef6aaecde0aa7d11731df11649

LICENCE contains the full GNU AGPL version 3 licence. Original copyright and dependency notices remain in the source archives.
